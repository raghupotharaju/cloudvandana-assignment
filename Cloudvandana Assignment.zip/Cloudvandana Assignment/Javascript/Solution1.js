function reverseWordsInSentence(sentence) {
    let words = sentence.split(' ');
    for (let i = 0; i < words.length; i++) {
        words[i] = reverseWord(words[i]);
    }
    let reversedSentence = words.join(' ');
    return reversedSentence;
}
function reverseWord(word) {
    return word.split('').reverse().join('');
}
let sentence = "This is a sunny day";
let reversedSentence = reverseWordsInSentence(sentence);
console.log(reversedSentence);
