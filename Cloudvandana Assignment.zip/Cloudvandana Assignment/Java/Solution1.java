import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class Solution1
{
    static void randomize( int arr[],int n)
    {
        Random r = new Random();
        for (int i=n-1; i>0;i--) {
            int j=r.nextInt(i+1);
            int temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
        System.out.println(Arrays.toString(arr));
    }
    public static void main(String[] args) 
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter Array size");
    	int n=sc.nextInt();
    	System.out.println("enter array elements");
    	int arr[]=new int[n];
    	for(int i=0;i<n;i++)
    	{
    		arr[i]=sc.nextInt();
    	}
        randomize(arr, n);
    }
}