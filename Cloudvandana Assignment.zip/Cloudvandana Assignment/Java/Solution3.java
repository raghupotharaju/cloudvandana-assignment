import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Solution3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = sc.nextLine().toLowerCase();
        boolean isPangram = isPangram(input);
        if (isPangram==true) {
            System.out.println("pangram");
        } else {
            System.out.println("not a pangram.");
        }
    }
    public static boolean isPangram(String input) {
        Set<Character> alphabetSet = new HashSet<>();
        for (char c = 'a'; c <= 'z'; c++) {
            alphabetSet.add(c);
        }
        for (char c : input.toCharArray()) {
            alphabetSet.remove(c);
        }
        return alphabetSet.isEmpty();
    }
}
